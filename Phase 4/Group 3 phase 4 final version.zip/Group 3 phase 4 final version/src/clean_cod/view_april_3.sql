-- select the database to use
use pms;
-- DROP THE VIEW IF IT EXISTS 
drop view if exists outstanding_m_request_veiw ;
/************************************************************************************************
*  	creates view called outstanding_m_request_veiw.												*
*	with the query result returned from teh maintenance_request table 							*
*	joined with the tenant table. with the maintenance_request status ='open'.					*	
*	the query result includes the description of the request, status and 						*
*	tenant's phone number.																		*
*************************************************************************************************/
create view outstanding_m_request_veiw as select description , 
status, phone_number as 'tenant\'s phone'  from maintenance_request as m join tenant as t on 
t.tenant_id = m.tenant_id   where m.status = 'open';
-- display all the information in the view  outstanding_m_request_veiw 
select  *  from   outstanding_m_request_veiw ;

