/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tran.phase4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author Thanh
 */
public class con {
    public con() {
    }
    
public Connection getConnection() {
    Connection connection = null;
    try {

//Establish mysql connection
        connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/PMS", "root", "123456789");
    } catch (SQLException exception) { //catch any exceptions that may have occured exception.printStackTrace(); //print any errors
        System.out.println("connection issue : " + exception.getLocalizedMessage());
    }
    return connection;
}
}
